#ifndef BESTIMAGE_H
#define BESTIMAGE_H

extern "C" __declspec (dllexport)
int load_compress_save(const char* in, int inlen, char* out, int* outlen, int customid = 1099999999);

#endif // BESTIMAGE_H
